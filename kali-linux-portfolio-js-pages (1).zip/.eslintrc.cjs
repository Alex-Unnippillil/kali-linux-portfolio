module.exports = {
  extends: ['next/core-web-vitals'],
  rules: {
    '@next/next/no-page-custom-font': 'off',
    '@next/next/no-img-element': 'off',
  },
};
