export { default } from '../../apps/pinball';
