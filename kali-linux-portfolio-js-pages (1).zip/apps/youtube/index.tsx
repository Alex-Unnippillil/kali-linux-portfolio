'use client';

import YouTubeApp from '../../components/apps/youtube';

export default function YouTubePage() {
  return (
    <div className="h-full w-full bg-ub-dark-grey font-sans text-ubt-cool-grey">
      <YouTubeApp />
    </div>
  );
}
