'use client';
import Blackjack from '../../components/apps/blackjack';
export default Blackjack;
