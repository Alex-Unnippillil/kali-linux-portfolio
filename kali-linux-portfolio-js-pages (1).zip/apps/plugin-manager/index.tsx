'use client';
import PluginManager from '../../components/apps/plugin-manager';

export default function PluginManagerApp() {
  return <PluginManager />;
}
