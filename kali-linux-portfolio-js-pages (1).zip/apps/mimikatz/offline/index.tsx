'use client';

import React from 'react';
import MimikatzOffline from '../../../components/apps/mimikatz/offline';

const MimikatzOfflineApp: React.FC = () => {
  return <MimikatzOffline />;
};

export default MimikatzOfflineApp;
